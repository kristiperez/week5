class GroceryItems {
    constructor(groceryName,quantity) {
        this.groceryName = groceryName
        this.quantity = quantity
    }
}